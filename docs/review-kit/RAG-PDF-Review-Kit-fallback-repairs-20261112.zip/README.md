# Eight-question fallback-repair review

Extract the ZIP and open START_HERE.html. Three immutable source-labelled recordings contain 8 + 6 + 2 outputs. The root index selects the latest output per question without relabelling any older output as a new commit. All 16 review rows are ungraded; human reviews remain zero. Earlier failures are preserved. AI-assisted inspection flags the extraneous الكلمة in the latest Arabic comparison and awkward count agreement; Arabic language acceptance remains unmet. The recorded answers are unchanged.

Only final answers, exact native citations, public original PDFs, source/model/settings metadata, frozen reference guides and blank review forms are included. No raw diagnostic archive, wire responses, logs or rejected proposals are included. No stable release or general Arabic acceptance is claimed.
