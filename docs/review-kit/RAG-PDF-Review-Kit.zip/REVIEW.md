# Independent source review

No human verdicts have been entered. Open each original PDF and check every requested part, relation, number, condition, negation, page and exact quotation. Arabic script alone does not establish faithful Arabic meaning. Read the full page, including columns, captions and surrounding qualifications.

Edit only reviewer, reviewer_type, verdict and notes in review.csv. A person who actually checked the sources may use reviewer_type=human; AI-assisted review must use ai_assisted. Use pass, partial or fail, and explain partial/fail. Do not convert citation checks or generated mode into semantic grades.

The packet is bound to its exact compact answers and frozen expectations; retrieved full-context passages are omitted, not replaced. Expected points were not generation input. Independent human review is still pending.

After review: python -m scripts.review_run summarize --run PATH_TO_PACKET --reviews PATH_TO_PACKET/review.csv --output PATH_TO_PACKET/human-summary.json
